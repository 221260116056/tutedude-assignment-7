import psycopg2

def create_table():
    try:
        conn = psycopg2.connect(
            dbname="postgres",
            user="postgres",
            password="12345678",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS employees (
                Name TEXT,
                ID INT,
                Age INT
            );
        ''')
        print('Table created successfully')
        conn.commit()
    except Exception as e:
        print(f"Error creating table: {e}")
    finally:
        conn.close()

def data():
    try:
        conn = psycopg2.connect(
            dbname="postgres",
            user="postgres",
            password="12345678",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()

        # Get user input
        name = input('Enter name: ')
        id = input('Enter id: ')
        age = input('Enter age: ')

        # Insert query
        query = 'INSERT INTO employees (Name, ID, Age) VALUES (%s, %s, %s);'
        cursor.execute(query, (name, id, age))

        print('Data added successfully')
        conn.commit()
    except Exception as e:
        print(f"Error inserting data: {e}")
    finally:
        conn.close()

# Run both functions
create_table()
data()
